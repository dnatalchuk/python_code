from distutils.core import setup

setup(
        name = "nester",
        version = '1.0.0',
        py_moules = ['nester'],
        author = 'dn',
        author_email = 'd.natalchuk@gmail.com',
        desciprtion = 'A simple printer of nested lists',
        )
