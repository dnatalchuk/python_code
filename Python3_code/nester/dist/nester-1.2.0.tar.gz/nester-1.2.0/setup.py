from distutils.core import setup

setup (
        name         = 'nester',
        version      = '1.2.0',
        py_modules   = ['nester'],
        author       = 'dn',
        author_email = 'd.natalchuk@gmail.com',
        url          = 'http://www.headfirstlabs/com',
        desciprtion  = 'A simple printer of nested lists',

      )